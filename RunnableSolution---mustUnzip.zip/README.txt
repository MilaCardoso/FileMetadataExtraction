FILES AND FOLDERS
XML_Source must be in the same root folder as MetadataExtractor.jar.
Do not rename XML_Source folder.

XML_Source containes xml template. DO NOT change the name of the template .xml.
------------------------------------------------------------------------------------------------------------------------------

HOW TO RUN
MetadataExtractor.jar is only runnable from cmd line.
Please run it as java -jar MetadataExtractor.jar fullPathNameToYourFolderFullOfTestFiles.

Example:
C:\Users\antonela.mrkalj\Desktop>java -jar MetadataExtractor.jar C:\\Users\\antonela.mrkalj\\git\\FileMetadataExtraction\\TEST
------------------------------------------------------------------------------------------------------------------------------

WHY MY CMD DOES NOT RECOGNISE JAVA
If your system does not recognise java command, please follow instructions on 
https://javatutorial.net/set-java-home-windows-10